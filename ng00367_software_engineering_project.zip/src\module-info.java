module ng00367.software.engineering.project {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    requires jasypt;
    requires junit;

    opens Controllers;
}